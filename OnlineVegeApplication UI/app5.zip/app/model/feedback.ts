

export interface Feedback {
feedbackId :  number;
customerId : number;
vegId : number;
rating : number;
comments : string;



}
