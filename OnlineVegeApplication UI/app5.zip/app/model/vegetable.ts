export interface Vegetable {
    vegId : number;
    name : string;
    type : string;
    price : number;
    quantity : number;

}
