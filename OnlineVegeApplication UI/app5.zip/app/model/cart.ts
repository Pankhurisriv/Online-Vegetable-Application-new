

export interface Cart {
cartId : number;
customeId : number;
vegId: number;

}

