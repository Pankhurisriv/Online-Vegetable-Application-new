import { Address } from "./address";






export interface Customer {
    customerId : number;
    name : string;
    mobileNumber : string;
    emailId : string;
    password : string;
    address : Address;



}
