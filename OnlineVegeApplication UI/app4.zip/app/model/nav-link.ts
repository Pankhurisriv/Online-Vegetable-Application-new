export interface NavLink {
}
