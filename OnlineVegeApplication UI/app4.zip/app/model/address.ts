
export interface Address {
    flatNo : string;
	buildingName : string;
	area : string;
	city  : string;
	state : string;
	pincode : number;
}
