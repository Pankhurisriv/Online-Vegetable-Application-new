import { DatePipe } from "@angular/common";


export interface Billingdetails {
    billingId : number;
	transactionMode : string;
	transactionDate : Date;
	transactionStatus : string;
	orderNo : number;
  
}
