import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feedbackcustomer',
  templateUrl: './feedbackcustomer.component.html',
  styleUrls: ['./feedbackcustomer.component.css']
})
export class FeedbackcustomerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
