import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feedbackinfo',
  templateUrl: './feedbackinfo.component.html',
  styleUrls: ['./feedbackinfo.component.css']
})
export class FeedbackinfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
