

export interface Admin  {
    adminId : number;
	name : string;
	contactNumber : number;

}
