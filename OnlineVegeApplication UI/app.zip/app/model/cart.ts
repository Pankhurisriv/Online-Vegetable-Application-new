import { Customer } from "./customer";

export interface Cart {

cartId : number;
customer : Customer;

}

