

export interface Billingdetails {
    billingId : number;
	transactionMode : string;
	transactionDate : Date;
	tranactionStatus : string;
	orderNo : number;
  
}
