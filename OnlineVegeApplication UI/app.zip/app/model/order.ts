import { Customer } from "./customer";

export interface Order {
    orderNo : number;
   customerId : number;
    totalAmount : number;
    orderDate : Date;
    status : string;
    vegId : number;

}
