import { Customer } from "./customer";
import { Vegetable } from "./vegetable";

export interface Feedback {
feedbackId :  number;
customer : Customer;
vegetable : Vegetable;
rating : number;
comments : string;



}
